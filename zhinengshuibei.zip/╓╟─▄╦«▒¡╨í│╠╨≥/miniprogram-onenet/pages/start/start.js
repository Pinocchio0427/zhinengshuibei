// start.js

Page({
    data: {

    },
    navigate1: function() {
        wx.navigateTo({
            url: '../wifi_station/temperature/temperature',
        })
    },
    navigate2: function() {
        wx.navigateTo({
            url: '../wifi_station/remind/remind',
        })
    }
    
})